<?
$MESS['SALE_HANDLERS_PAY_SYSTEM_TEMPLATE_BEGATEWAY_ERIP_CHECKOUT_DESCRIPTION'] = 'Услугу предоставляет сервис <b>&laquo;bePaid&raquo;</b>.';
$MESS['SALE_HANDLERS_PAY_SYSTEM_TEMPLATE_BEGATEWAY_ERIP_CHECKOUT_SUM'] = 'Сумма к оплате: #SUM#';
$MESS['SALE_HANDLERS_PAY_SYSTEM_TEMPLATE_BEGATEWAY_ERIP_CHECKOUT_WARNING_RETURN'] = '<b>Обратите внимание:</b> если вы откажетесь от покупки, для возврата денег вам придется обратиться в магазин.';
$MESS['SALE_HANDLERS_PAY_SYSTEM_TEMPLATE_BEGATEWAY_ERIP_INSTRUCTION'] = '
Если Вы осуществляете платеж в кассе банка, пожалуйста, сообщите кассиру о необходимости проведения платежа через ЕРИП.</br>
<br>
Для проведения платежа необходимо найти магазин в дереве ЕРИП по коду услуги <strong>#ERIP_SERVICE_CODE#</strong> или воспользоваться инструкцией:<br>
<ol>
  <li>Выбрать пункт ЕРИП</li>
  <li>Выбрать последовательно пункты: <i>#INSTRUCTION#</i></li>
  <li>Ввести номер <strong>#ACCOUNT_NUMBER#</strong></li>
  <li>Проверить корректность информации</li>
  <li>Совершить платеж</li>
</ol>';
$MESS['SALE_HANDLERS_PAY_SYSTEM_TEMPLATE_BEGATEWAY_ERIP_QR_INSTRUCTION'] = 'Если вы пользуйтесь мобильными приложением банка, то используйте его, чтобы отсканировать QR-код и осуществить платеж.';
