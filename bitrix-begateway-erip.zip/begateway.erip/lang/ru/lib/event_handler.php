<?
$MESS['SALE_HPS_BEGATEWAY_ERIP_EA_STATUS_CHANGE_ERROR'] = 'Ошибка создания ЕРИП счета';
$MESS['SALE_HPS_BEGATEWAY_ERIP_EC_STATUS_CHANGE_ERROR'] = 'Ошибка отмены ЕРИП счета';
$MESS['SALE_HPS_BEGATEWAY_ERIP_EA_STATUS_CHANGE_SUCCESS'] = 'Счет в ЕРИП создан успешно';
$MESS['SALE_HPS_BEGATEWAY_ERIP_EMAIL_SUBJECT'] = '[#SITE_NAME#] инструкция по оплате заказа через ЕРИП';
