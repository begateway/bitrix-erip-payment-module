<?
$MESS['SALE_HPS_BEGATEWAY_ERIP_RESPONSE_DECODE_ERROR'] = 'Ошибка декодирования строки JSON';
$MESS['SALE_HPS_BEGATEWAY_ERIP_ERROR_STATUS'] = 'Некорректный статус платежа: #STATUS#';
$MESS['SALE_HPS_BEGATEWAY_ERIP_ERROR_SIGNATURE'] = 'Некорректная подпись вебхука';
$MESS['SALE_HPS_BEGATEWAY_ERIP_TRANSACTION'] = 'Транзакция #ID#';
$MESS['SALE_HPS_BEGATEWAY_ERIP_ERROR_SUM'] = 'Сумма платежа не совпадает с суммой оплаты';
$MESS['SALE_HPS_BEGATEWAY_ERIP_CONFIRM_ERROR'] = 'Оплата может быть только отменена';
