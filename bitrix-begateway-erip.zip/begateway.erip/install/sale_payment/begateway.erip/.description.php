<?php
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/begateway.erip/handler/.description.php');
