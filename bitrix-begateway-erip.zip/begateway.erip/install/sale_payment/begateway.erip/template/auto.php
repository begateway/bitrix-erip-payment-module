<?php
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/begateway.erip/template/auto.php');
