<?php
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/begateway.erip/template/manual.php');
