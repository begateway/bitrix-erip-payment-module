<?
$arModuleVersion = array(
    "VERSION" => "2.1.10",
    "VERSION_DATE" => "2023-10-12 09:20:00"
);
