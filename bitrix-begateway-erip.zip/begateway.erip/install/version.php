<?
$arModuleVersion = array(
    "VERSION" => "2.0.5",
    "VERSION_DATE" => "2021-10-12 09:30:00"
);
