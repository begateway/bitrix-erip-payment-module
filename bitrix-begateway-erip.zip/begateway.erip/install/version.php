<?
$arModuleVersion = array(
    "VERSION" => "2.0.0",
    "VERSION_DATE" => "2021-02-01 12:45:59"
);
