<?
$MESS["DEVTM_ERIP_DOMAIN_API_DESC"] = "Домен API";
$MESS["DEVTM_ERIP_SHOP_ID_DESC"] = "ID магазина";
$MESS["DEVTM_ERIP_SHOP_KEY_DESC"] = "Ключ магазина";
$MESS["DEVTM_ERIP_NOTIFICATION_URL_DESC"] = "Страница уведомления после оплаты";
$MESS["DEVTM_ERIP_SERVICE_NUMBER_DESC"] = "Номер сервиса в системе ЕРИП";
$MESS["DEVTM_ERIP_COMPANY_NAME_DESC"] = "Имя компании в системе ЕРИП";
$MESS["DEVTM_ERIP_SALE_NAME_DESC"] = "Имя магазина в системе ЕРИП";
$MESS["DEVTM_ERIP_PATH_TO_SERVICE_DESC"] = "Путь к услуге в дереве системы ЕРИП";
$MESS["DEVTM_ERIP_FOR_PAYER_DESC"] = "Описание сервиса для плательщика";
$MESS["DEVTM_ERIP_TAB_NAME"] = "Настройка модуля";
$MESS["DEVTM_ERIP_TAB_DESC"] = "Настройка модуля Расчёт (ЕРИП)";
$MESS["DEVTM_ERIP_SAVE_BTN_NAME"] = "Сохранить";
$MESS["DEVTM_ERIP_RESET_BTN_NAME"] = "Сбросить";
$MESS["DEVTM_ERIP_RESTORE_WARNING"] = "Текущие значения будут удалены.";
$MESS["DEVTM_ERIP_RECEIPT_PAYER_DESC"] = "Ответ покупателю";
$MESS["DEVTM_ERIP_PAYMENT_DESC"] = "\"Система \"Расчет (ЕРИП)\" позволяет произвести оплату в любом удобном для Вас месте, в удобное для Вас время, в удобном для Вас пункте банковского обслуживания – банкомате, инфокиоске, интернет-банке, кассе банков, с помощью мобильного банкинга и т.д.
Вы можете осуществить платеж с использованием наличных денежных средств, электронных денег и банковских платежных карточек в пунктах банковского обслуживания банков, которые оказывают услуги по приему платежей, а также посредством инструментов дистанционного банковского обслуживания.";