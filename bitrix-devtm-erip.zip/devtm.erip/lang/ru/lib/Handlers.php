<?
$MESS["DEVTM_ERIP_ORDER_DESCRIPTION"] = "Заказ ##ORDER_ID#";
$MESS["DEVTM_ERIP_UNKNOWN_RESPONSE"] = "Ошибка в ответе от сервера";
$MESS["DEVTM_ERIP_NOT_PENDING_RESPONSE"] = "Неизвестныйе статус ответа";
