<?
$MESS["DEVTM_ERIP_PAYMENT_ACTION_TITLE"] = "Обработчик платёжной системы \"Расчёт (ЕРИП)\"";