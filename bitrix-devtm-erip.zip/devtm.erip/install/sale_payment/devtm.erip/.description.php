<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();?><?
use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);

$psTitle = Loc::getMessage("DEVTM_ERIP_PAYMENT_ACTION_TITLE");
$psDescription = Loc::getMessage("DEVTM_ERIP_PAYMENT_ACTION_DESC");

?>
