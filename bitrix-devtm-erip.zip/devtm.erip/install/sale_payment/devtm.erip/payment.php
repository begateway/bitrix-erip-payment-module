<?
use \Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);

echo "<p>".Loc::getMessage("DEVTM_ERIP_PAYMENT_OK_TEXT")."</p>";

