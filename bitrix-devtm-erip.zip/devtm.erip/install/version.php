<?

$arModuleVersion = array(
    "VERSION" => "1.1.1",
    "VERSION_DATE" => "2016-02-10 00:00:00"
);
