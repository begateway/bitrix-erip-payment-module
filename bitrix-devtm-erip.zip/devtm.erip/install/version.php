<?

$arModuleVersion = array(
    "VERSION" => "1.1.3",
    "VERSION_DATE" => "2016-10-26 18:18:00"
);
