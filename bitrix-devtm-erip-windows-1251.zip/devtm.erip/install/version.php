<?

$arModuleVersion = array(
    "VERSION" => "1.1.2",
    "VERSION_DATE" => "2016-09-13 11:16:00"
);
