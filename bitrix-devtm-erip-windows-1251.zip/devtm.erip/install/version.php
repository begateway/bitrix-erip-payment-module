<?

$arModuleVersion = array(
    "VERSION" => "1.1.4",
    "VERSION_DATE" => "2016-10-28 14:16:30"
);
